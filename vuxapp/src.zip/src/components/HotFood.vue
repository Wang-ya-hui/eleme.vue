<template>
    <div class="hot-food">
        <ul>
            <li><a href="#">{{food.search_word}}</a></li>
        </ul>
    </div>
</template>

<script>
import Vue from 'vue'
export default {
    name: 'hot-food',
    props: ['food']
}
</script>

<style scoped>
    .hot-food{
        /* 怎样让他排成一行 */
        height: 2rem;
        line-height: 2rem;
        float: left;
        color: white;
        margin-left: 1rem;
        margin-right: 1rem;
    }
</style>