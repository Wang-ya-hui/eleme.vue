<template>
    <div id="order">
        订单
    </div>
</template>

<script>
    export default {
        name: 'order'
    }
</script>
<style>

</style>