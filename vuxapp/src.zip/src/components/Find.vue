<template>
        <div id="find">
            发现
        </div>
    </template>
    
    <script>
        export default {
            name: 'find'
        }
    </script>
    <style>
    
    </style>