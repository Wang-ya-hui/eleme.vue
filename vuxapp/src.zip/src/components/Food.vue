<template>
    <div id="food">
        <!-- 获取定位 -->
        <div class="food-city">
            <!-- 在定位这里加一个过滤器 -->
            <span class="fa fa-map-marker"></span>
            <i>{{city}}</i>
        </div>
        <!-- 获取天气 -->
        <div class="food-weather">
            <div class="food-weather-word">
                <h2>{{temperature}}</h2>
                <p>{{description}}</p>
            </div>
            <img :src='this.image_hash' alt="图片找不到">
        </div>
        <!-- 搜索框 -->
        <div>
             <a href="#">
                <div class="food-search">
                    <span class="fa fa-search"></span>
                    搜索商家，商品名称
                </div>
            </a>  
        </div>
        <!-- 获取热搜 -->
        <div class="food-hotsearch">
            <hot-food v-for="hot in hots" :food="hot" :key="hots.word"></hot-food>
        </div>
        <!-- 获取轮播 -->
        <div>
            <lun-bo v-for="(lunbodata,i) in lunbodatas" :lun="lunbodatas" :imgs="lunbodatas.imgsrc[i]"></lun-bo>
        </div>
        <!-- 获取推荐商家 -->
    </div>
</template>

<script>
    import HotFood from './HotFood'
    import LunBo from './LunBo'
    export default {
        name: 'food',
        components: {
            HotFood,LunBo
        },
        data () {
            return {
                city: "城市定位",
                temperature: "温度",
                description: "天气",
                image_hash: "天气图标",
                image_hash1: "",
                image_http: "https://fuss10.elemecdn.com/.png?imageMogr/thumbnail/!69x69r/gravity/Center/crop/69x69/",
                img_http: "//fuss10.elemecdn.com/.jpeg?imageMogr/format/webp/thumbnail/!90x90r/gravity/Center/crop/90x90/",
                hots: {},
                lunbodatas: {},
                img_src: [],
            }
        },
        mounted () {
            // console.log('获取定位');
            // 发送请求
            this.http.get('/elemeapi/v2/pois/ww8p3nhuhtsh').then(res=>{
                // console.log(res.data);
                // console.log(this.city);
                if (res.data.error = '0') {
                    this.city = res.data.address;
                    // console.log(this.city);
                } else {
                    this.city = "未能获得地址"
                }
            },err=>{
              
            });
            console.log('获取天气');
            this.http.get('/elemeapi/bgs/weather/current?latitude=37.87059&longitude=112.550667').then(res=>{
                // console.log(res.data);
                if (res.data.highlight = '0') {
                    this.temperature = res.data.temperature;
                    this.description = res.data.description;
                    this.image_hash1 = res.data.image_hash.substr(0,1)+"/"+res.data.image_hash.substr(1,2)+"/"+res.data.image_hash.substr(3);
                    // console.log(this.image_hash1);
                    this.image_hash = this.image_http.substr(0,28)+this.image_hash1+this.image_http.substr(28);
                    // console.log(this.image_hash);
                  

                } else {
                    
                }
            },err=>{
                
            });
            // 热搜
            this.http.get('/elemeapi/shopping/v3/hot_search_words?latitude=37.87059&longitude=112.550667',{
                // params:{offset:this.roomlist.length/20}
            })
            .then(res=>{
                // console.log(res.data);
                if (res.data) {
                    this.hots = res.data;
                    // console.log(this.hots.word);
                } else {
                }
            },err=>{
                console.log(89);
            });
            // 轮播
            this.http.get('/elemeapi/shopping/v2/entries?latitude=38.01135&longitude=112.44299&templates[]=main_template').then(res=>{
                console.log(res.data);
                if (res.data) {
                    this.lunbodatas = res.data[0].entries;
                    // console.log(this.lunbodatas);
                    // console.log(this.lunbodatas[0].business_flag)
                    for( var i = 0; i<13;i++){
                        this.img_src.push(this.img_http.substr(0,22)+res.data[0].entries[i].image_hash.substr(0,1)+"/"+res.data[0].entries[i].image_hash.substr(1,2)+"/"+res.data[0].entries[i].image_hash.substr(3)+this.img_http.substr(22));
                    };
                    this.lunbodatas.imgsrc = this.img_src;
                    console.log(this.lunbodatas.imgsrc);
                   
                } else {
                    
                }
            }),err=>{

            };
        }
    }
</script>
<style scoped>
#food{
    height: 11rem;
    width: 100%;
    background-color: #0092FF;
    margin-top: 0;
    /* overflow: hidden; */
}
.food-city{
    color: white;
    width: 13rem;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
    margin-top: 0;
    padding-top: 1rem;
    padding-left: 1rem;
    font-size: 1.5rem;
}
.food-weather{
    color: white;
    font-size: 0.5rem;
    position: absolute;
    right: 1rem;
    top: 1rem;
}
.food-weather img{
    width: 3rem;
    height: 3rem;
}
.food-weather-word{
    position: absolute;
    right: 3rem;
    width: 2rem;
    text-align: center
}
.food-search{
    margin-top: 1rem;
    margin-left: 1rem;
    margin-right: 1rem;
    background-color: white;
    color: gainsboro;
    height: 3rem;
    line-height: 3rem;
    text-align: center;
}
/* 热搜 */
.food-hotsearch{
    /* width: 100%; */
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
</style>