<template>
        <div id="me">
            我的
        </div>
    </template>
    
    <script>
        export default {
            name: 'me'
        }
    </script>
    <style>
    
    </style>