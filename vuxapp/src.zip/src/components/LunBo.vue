<template>
    <div class="lun-bo">
        <img :src="simg" alt="">
        {{lun.name}}
        haah 
    </div>
</template>
<script>
    import Vue from 'vue'
    export default {
        name: 'lun-bo',
        props: ['lun','imgs'],
        data(){
            return {
                simg: this.imgs
            }
        }
    }
</script>